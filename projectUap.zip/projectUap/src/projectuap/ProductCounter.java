/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projectuap;

/**
 *
 * @author Acer
 */
public interface ProductCounter {
    public double TAX = 0.0;
    public void hitungJumlahProduk();
    public void hitungHargaProduk();
    
}
